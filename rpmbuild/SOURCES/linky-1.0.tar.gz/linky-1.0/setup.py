import setuptools

setuptools.setup(
    #metadata:
    include_package_data=True,
    name='linky',     
    version='1.0',
    description='aplicativo para generar inventarios con Ansible',
    author='DXC-SRE-Middleware',
    url = 'https://github.com/renatogermanib/linky-rpm',
    packages=setuptools.find_packages(),
    install_requires=['pathlib', 'ipaddress', 'jq', 'typing', 'argparse', 'paramiko', 'audioop', 'progress', 're'], #dependencias
    classifiers=[ #tags
        "Programming Language :: Python :: 3",
         "Operating System :: OS Independent",
    ],
)
